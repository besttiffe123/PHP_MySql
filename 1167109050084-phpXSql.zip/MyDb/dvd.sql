-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 08, 2026 at 12:25 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dvd`
--

-- --------------------------------------------------------

--
-- Table structure for table `dvdactor`
--

CREATE TABLE `dvdactor` (
  `aid` int(3) NOT NULL,
  `aname` varchar(20) NOT NULL,
  `alastname` varchar(20) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `age` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `dvdactor`
--

INSERT INTO `dvdactor` (`aid`, `aname`, `alastname`, `gender`, `age`) VALUES
(1, 'Matt', 'Damon', 'M', 35),
(2, 'Sandra', 'Bullock', 'W', 62),
(3, 'Henry', 'Fonda', 'M', 77),
(4, 'Alexis', 'Bledel', 'W', 45),
(5, 'Vin', 'Diesel', 'M', 59);

-- --------------------------------------------------------

--
-- Table structure for table `dvdcustomer`
--

CREATE TABLE `dvdcustomer` (
  `cid` int(3) NOT NULL,
  `cname` varchar(20) NOT NULL,
  `clastname` varchar(20) NOT NULL,
  `age` int(3) NOT NULL,
  `telephone` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `dvdcustomer`
--

INSERT INTO `dvdcustomer` (`cid`, `cname`, `clastname`, `age`, `telephone`) VALUES
(1, 'Liam', 'Grant', 18, '6548951234'),
(2, 'Emma', 'Jacobson', 20, '06195734619'),
(3, 'Noah', 'Hamm', 20, '06195734619'),
(4, 'Olivia', 'Tobin', 21, '06195325619'),
(5, 'Lucas', 'Grubbs', 22, '06195785419'),
(6, 'pitthawat', 'Chankaew', 20, '0952836616'),
(7, 'uraiwan', 'in', 20, '025494276');

-- --------------------------------------------------------

--
-- Table structure for table `dvdmovie`
--

CREATE TABLE `dvdmovie` (
  `mid` int(3) NOT NULL,
  `mname` varchar(50) NOT NULL,
  `language` varchar(20) NOT NULL,
  `genres` varchar(50) NOT NULL,
  `price` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `dvdmovie`
--

INSERT INTO `dvdmovie` (`mid`, `mname`, `language`, `genres`, `price`) VALUES
(1, 'Inception', 'Eng', 'Sci-Fi', 249),
(2, 'Inception', 'Eng', 'Sci-Fi', 249),
(3, 'The Dark Knight', 'Eng', 'Superhero', 200),
(4, 'Titanic', 'Eng', 'Romance', 250),
(5, 'Pulp Fiction', 'Eng', 'Crime', 35),
(6, 'Up', 'Eng', 'Drama', 130),
(7, 'test test', 'Eng', 'Drama', 100);

-- --------------------------------------------------------

--
-- Table structure for table `junction`
--

CREATE TABLE `junction` (
  `mid` int(3) NOT NULL,
  `aid` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `pid` int(3) NOT NULL,
  `cid` int(3) NOT NULL,
  `mid` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dvdactor`
--
ALTER TABLE `dvdactor`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `dvdcustomer`
--
ALTER TABLE `dvdcustomer`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `dvdmovie`
--
ALTER TABLE `dvdmovie`
  ADD PRIMARY KEY (`mid`),
  ADD KEY `mid` (`mid`);

--
-- Indexes for table `junction`
--
ALTER TABLE `junction`
  ADD PRIMARY KEY (`mid`,`aid`),
  ADD KEY `aid` (`aid`),
  ADD KEY `mid` (`mid`),
  ADD KEY `aid_2` (`aid`),
  ADD KEY `mid_2` (`mid`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`pid`),
  ADD KEY `cid` (`cid`),
  ADD KEY `mid` (`mid`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `junction`
--
ALTER TABLE `junction`
  ADD CONSTRAINT `aid` FOREIGN KEY (`aid`) REFERENCES `dvdactor` (`aid`),
  ADD CONSTRAINT `mid` FOREIGN KEY (`mid`) REFERENCES `dvdmovie` (`mid`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `cid` FOREIGN KEY (`cid`) REFERENCES `dvdcustomer` (`cid`),
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`mid`) REFERENCES `dvdmovie` (`mid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
