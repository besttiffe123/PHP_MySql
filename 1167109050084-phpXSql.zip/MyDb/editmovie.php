<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php
        if(!isset($_GET['mid'])){
            header("refresh: 0; url=mainmenumovie.php");
        }
        require 'conn.php';
        $sql = "SELECT * FROM dvdmovie WHERE mid='$_GET[mid]'";
        $result = $conn->query($sql);
        $row = mysqli_fetch_array($result);
    ?>
    <form method="post" action="editsuccessmovie.php">
        <p>
            <label>ชื่อหนัง</label>
            <input type="text" name="mid" id="mid" value="<?=$row['mid'];?>" hidden>
            <input type="text" name="mname" id="mname" value="<?=$row['mname'];?>"/>
        </p>

        <p>
            <label>ภาษา</label>
            <input type="text" name="language" id="language" value="<?=$row['language'];?>"/>
        </p>

        <p>
            <label>ประเภทหนัง</label>
            <input type="text" name="genres" id="genres" value="<?=$row['genres'];?>"/>
        </p>

        <p>
            <label>ราคา</label>
            <input type="text" name="price" id="price" value="<?=$row['price'];?>"/>
        </p>
        <input type="submit" value="บันทึก">
        <a href='mainmenumovie.php'><button type="button"> Home</button></a>
    </form>
</body>
</html>