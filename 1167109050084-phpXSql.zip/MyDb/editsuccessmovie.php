<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
            require 'conn.php';
            $sql_update="UPDATE dvdmovie SET mname='$_POST[mname]',language='$_POST[language]' ,genres='$_POST[genres]' ,price='$_POST[price]' WHERE mid='$_POST[mid]'";

            $result= $conn->query($sql_update);

            if(!$result) {
                die("Error God Damn it : ". $conn->error);
            } else {

                echo "Edit Success <br>";
                header("refresh: 1; url=mainmenumovie.php");
            }

        ?>
</body>
</html