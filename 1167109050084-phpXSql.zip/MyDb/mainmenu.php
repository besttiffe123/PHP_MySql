<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php
        require 'conn.php';
        $sql = "SELECT * FROM dvdcustomer";
        $result = $conn->query($sql);
        if(!$result){
            die("Error : ". $sonn->$conn_error);
                    }
    ?>
    <h1>Customer Data</h1><br>
    <table>
        <thead>
            <tr>
                <th>รหัสลูกค้า</th>
                <th>ชื่อ-นามสกุล</th>
                <th>อายุ</th>
                <th>เบอร์โทร</th>
                <th> ธุรกรรม </th>
            </tr>
        </thead>
        <tbody>
            <?php // show data by fetch from database
                if($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo"<tr><td>".$row["cid"]."</td>"."<td>".$row["cname"]." ".$row["clastname"]."</td>"."<td>".$row["age"]."</td>"."<td>".$row["telephone"]."</td>"."<td>"."<a href='editbio.php?cid=".$row["cid"]."'><button> Edit </button></a>"."</td>";
                        echo "</tr>";    
                    }
                }else {
                    echo "0 results";
                }
                $conn->close();
            ?>
        </tbody>
    </table>
    <br>
    <a href='insertbio.php'><button> Insert Customer</button></a>
</body>
</html>