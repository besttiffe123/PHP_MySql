<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
            require 'conn.php';
$sql_update="UPDATE dvdcustomer SET cname='$_POST[cname]',clastname='$_POST[clastname]' ,age='$_POST[age]' ,telephone='$_POST[telephone]' WHERE cid='$_POST[cid]' ";

            $result= $conn->query($sql_update);

            if(!$result) {
                die("Error God Damn it : ". $conn->error);
            } else {
            header("refresh: 1; url=mainmenu.php");
            echo "Edit Success <br>";
            }

        ?>
</body>
</html>