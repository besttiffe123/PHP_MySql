<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <form method="post" action="insertbiosuccess.php">
        <p>

            <label>รหัสลูกค้า</label>
            <input type="text" name="cid" id="cid">

        </p>

        <p>

            <label>ชื่อ</label>
            <input type="text" name="cname" id="cname">

        </p>

        <p>

            <label>นามสกุล</label>

            <input type="text" name="clastname" id="clastname">

        </p>

        <p>

            <label>อายุ</label>

            <input type="text" name="age" id="age">

        </p>

        <p>

            <label>เบอร์โทร</label>

            <input type="text" name="telephone" id="telephone">

        </p>
        <input type="submit" value="บันทึก">
        <a href='mainmenu.php'> <button> Home </button></a>
    </form>
</body>
</html>