<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <form method="post" action="insertmoviesuccess.php">
        <p>

            <label>รหัสหนัง</label>
            <input type="text" name="mid" id="mid">

        </p>

        <p>

            <label>ชื่อหนัง</label>
            <input type="text" name="mname" id="mname">

        </p>

        <p>

            <label>ภาษา</label>

            <input type="text" name="language" id="language">

        </p>

        <p>

            <label>ประเภทหนัง</label>

            <input type="text" name="genres" id="genres">

        </p>

        <p>

            <label>ราคา</label>

            <input type="text" name="price" id="price">

        </p>
        <input type="submit" value="บันทึก">
        <a href='mainmenumovie.php'> <button> Home </button></a>
    </form>
</body>
</html>