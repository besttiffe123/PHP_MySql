<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connect to database dvd</title>
</head>
<body>
<?php 
$conn = new mysqli('localhost','root','','dvd');
$conn->query("SET NAMES utf8");
if($conn->connect_error){ 
    die("Connection Fail God damn it ". $conn->$conn_error);
} 

echo "hello guy, db connectted"; 

?>
</body>
</html>