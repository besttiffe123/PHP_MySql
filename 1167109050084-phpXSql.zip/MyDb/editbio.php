<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php
        if(!isset($_GET['cid'])){
            header("refresh: 0; url=mainmenu.php");
        }
        require 'conn.php';
        $sql = "SELECT * FROM dvdcustomer WHERE cid='$_GET[cid]'";
        $result = $conn->query($sql);
        $row = mysqli_fetch_array($result);
    ?>
    <form method="post" action="editsuccess.php">
        <p>

            <label>ชื่อ</label>
            <input type="text" name="cid" id="cid" value="<?=$row['cid'];?>" hidden>
            <input type="text" name="cname" id="cname" value="<?=$row['cname'];?>" />

        </p>

        <p>

            <label>นามสกุล</label>

            <input type="text" name="clastname" id="clastname" value="<?=$row['clastname'];?>" />

        </p>

        <p>

            <label>อายุ</label>

            <input type="text" name="age" id="age" value="<?=$row['age'];?>" />

        </p>

        <p>

            <label>เบอร์โทร</label>

            <input type="text" name="telephone" id="telephone" value="<?=$row['telephone'];?>" />

        </p>
        <input type="submit" value="บันทึก">
        <a href='mainmenu.php'><button> Home</button></a>
    </form>
</body>
</html>