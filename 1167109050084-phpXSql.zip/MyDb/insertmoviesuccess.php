<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    require 'conn.php';
    $sql_update="INSERT INTO dvdmovie(mid,mname,language,genres,price) VALUES ('$_POST[mid]','$_POST[mname]','$_POST[language]' ,'$_POST[genres]' ,'$_POST[price]')";

    $result= $conn->query($sql_update);

    if(!$result) {
        die("Error God Damn it : ". $conn->error);
    } else {

    echo "Insert Success <br>";
    header("refresh: 1; url=mainmenumovie.php");
    }

?>
</body>
</html>