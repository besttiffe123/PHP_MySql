<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php
        require 'conn.php';
        $sql = "SELECT * FROM dvdmovie";
        $result = $conn->query($sql);
        if(!$result){
            die("Error : ". $conn->error);
                    }
    ?>
    <h1>Movie</h1><br>
    <table>
        <thead>
            <tr>
                <th>รหัสหนัง</th>
                <th>ชื่อหนัง</th>
                <th>ภาษา</th>
                <th>ประเภทหนัง</th>
                <th>ราคา</th>
            </tr>
        </thead>
        <tbody>
            <?php // show data by fetch from database
                if($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo"<tr><td>".$row["mid"]."</td>"."<td>".$row["mname"]."</td>"."<td>".$row["language"]."</td>"."<td>".$row["genres"]."</td>"."<td>".$row["price"]."</td>"."<td>"."<a href='editmovie.php?mid=".$row["mid"]."'><button> Edit </button></a>"."</td>";
                        echo "</tr>";    
                    }
                }else {
                    echo "0 results";
                }
                $conn->close();
            ?>
        </tbody>
    </table>
    <br>
    <a href='insertmovie.php'><button> Insert Movie</button></a>
</body>
</html>